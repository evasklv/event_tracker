import os
import mysql.connector
import logging
from dotenv import load_dotenv

logging.basicConfig(level=logging.DEBUG)

# Load environment variables from .env file
load_dotenv()

DB_HOST = os.getenv('DB_HOST')
DB_USER = os.getenv('DB_USER')
DB_PASSWORD = os.getenv('DB_PASSWORD')
DB_NAME = os.getenv('DB_NAME')

# Ensure all environment variables are set
if not all([DB_HOST, DB_USER, DB_PASSWORD, DB_NAME]):
    logging.error("Database configuration environment variables are not set properly.")
    exit(1)

def get_db_connection():
    try:
        connection = mysql.connector.connect(
            host=DB_HOST,
            user=DB_USER,
            password=DB_PASSWORD,
            database=DB_NAME
        )
        return connection
    except mysql.connector.Error as err:
        logging.error(f"Error: {err}")
        return None

def _create_tables():
    connection = get_db_connection()
    if connection is None:
        logging.error("Failed to connect to database.")
        return
    cursor = connection.cursor()
    try:
        with connection.cursor() as cursor:
            logging.debug("Creating tables...")
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS events (
                id INT AUTO_INCREMENT PRIMARY KEY,
                repo_name VARCHAR(255),
                event_time DATETIME,
                event_type VARCHAR(255)
            )
            """)
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS statistics (
                id INT AUTO_INCREMENT PRIMARY KEY,
                repo_name VARCHAR(255),
                event_type VARCHAR(255),
                avg_time_between_events FLOAT
            )
            """)          
            connection.commit()
            logging.debug("Tables created successfully.")
    except mysql.connector.Error as err:
        logging.error(f"Error creating tables: {err}")
        connection.rollback()
    finally:
        cursor.close()
        connection.close()

def _create_indexes():
    connection = get_db_connection()
    if connection is None:
        logging.error("Failed to connect to database.")
        return
    try:
        with connection.cursor() as cursor:
            # Create an index on the event_time column in events table
            cursor.execute("""
            CREATE INDEX idx_event_time ON events(event_time)
            """)
            # Create an index on the repo_name and event_type columns in statistics table
            cursor.execute("""
            CREATE INDEX idx_statistics_repo_event ON statistics(repo_name, event_type)
            """)
            connection.commit()
            logging.debug("Indexes created successfully.")
    except mysql.connector.Error as err:
        if err.errno == 1061:  # Duplicate key name error
            logging.debug("Indexes already exist.")
        else:
            logging.error(f"Error creating indexes: {err}")
            connection.rollback()
    finally:
        cursor.close()
        connection.close()

# Cleans old events from the database based on the defined rolling window
def clean_old_events():
    connection = get_db_connection()
    if connection is None:
        logging.error("Failed to connect to database.")
        return
    cursor = connection.cursor()

    try:
        # Ensure event_time is indexed for efficient query execution
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_event_time ON events(event_time)
        """)

        # Delete events older than 7 days in batches to avoid locking the table
        rows_deleted = 1
        while rows_deleted > 0:
            cursor.execute("""
                DELETE FROM events
                WHERE event_time < NOW() - INTERVAL %s DAY
                LIMIT 1000
            """, (ROLLING_WINDOW_DAYS,))
            rows_deleted = cursor.rowcount
            connection.commit()
            logging.debug(f"{rows_deleted} old events deleted based on time.")

        # Check and delete events to keep the count within 500
        cursor.execute("SELECT COUNT(*) FROM events")
        event_count = cursor.fetchone()[0]

        if event_count > MAX_EVENTS:
            # Delete excess events in batches
            excess_rows = event_count - MAX_EVENTS
            while excess_rows > 0:
                batch_size = min(excess_rows, 1000)
                cursor.execute("""
                    DELETE FROM events
                    ORDER BY event_time ASC
                    LIMIT %s
                """, (batch_size,))
                rows_deleted = cursor.rowcount
                excess_rows -= rows_deleted
                connection.commit()
                logging.debug(f"{rows_deleted} old events deleted to maintain max count.")
    except mysql.connector.Error as err:
        logging.error(f"Error cleaning old events: {err}")
        connection.rollback()
    finally:
        cursor.close()
        connection.close()

_create_tables()
_create_indexes()