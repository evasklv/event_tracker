import json
import logging
from datetime import datetime, timedelta
import asyncio

import aiohttp
import requests
import requests_cache
import certifi
import ssl
import mysql.connector
from flask import Flask, jsonify, request
from apscheduler.schedulers.background import BackgroundScheduler
from sql_part import get_db_connection, clean_old_events  # Import from sql_part.py

# set up the basic configuration for logging and log level
logging.basicConfig(level=logging.DEBUG)

# Configure caching to reduce API requests
requests_cache.install_cache('github_cache', expire_after=300)

# GitHub API URL and configurations
GITHUB_API_URL = 'https://api.github.com'
MAX_REPOSITORIES = 5
ROLLING_WINDOW_DAYS = 7
MAX_EVENTS = 500

# Initialize Flask app
app = Flask(__name__)

async def _fetch_events(session, repo_name):
    """
    Fetches events from the GitHub API for a given repository.

    @param session: An aiohttp ClientSession.
    @type session: aiohttp.ClientSession
    @param repo_name: The name of the repository.
    @type repo_name: str
    @return: The list of events for the repository.
    @rtype: list
    """
    url = f"{GITHUB_API_URL}/repos/{repo_name}/events"
    headers = {'Accept': 'application/vnd.github.v3+json'}
    ssl_context = ssl.create_default_context(cafile=certifi.where())

    logging.debug(f"Making GitHub API request to {url}")

    try:
        async with session.get(url, headers=headers, ssl=ssl_context) as response:
            response.raise_for_status()  # Raise an exception for HTTP errors
            from_cache = getattr(response, 'from_cache', False)
            if from_cache:
                logging.debug(f"Response for {repo_name} from cache.")
            else:
                logging.info(f"GitHub API request successful for {repo_name}")
            return await response.json()
    except aiohttp.ClientError as err:
        logging.error(f"HTTP Request failed for {repo_name}: {err}")
        return []

async def _process_and_store_events(repo_names):
    """
    Processes and stores events for the given repositories.

    @param repo_names: The list of repository names.
    @type repo_names: list
    """
    async with aiohttp.ClientSession() as session:
        tasks = [_fetch_events(session, repo) for repo in repo_names]
        results = await asyncio.gather(*tasks)
        
        all_events = []
        for events in results:
            all_events.extend(events)

    logging.info(f'Retrieved {len(all_events)} events in total')

    processed_events = []
    current_time = datetime.now()
    start_time = current_time - timedelta(days=ROLLING_WINDOW_DAYS)

    for event in all_events:
        event_time = datetime.strptime(event['created_at'], "%Y-%m-%dT%H:%M:%SZ")
        repo_name = event['repo']['name']
        event_type = event['type']

        if event_time >= start_time and len(processed_events) < MAX_EVENTS:
            processed_events.append({
                'repo_name': repo_name,
                'event_time': event_time,
                'event_type': event_type
            })

    logging.info(f'Processed events: {processed_events}')
    _store_in_database(processed_events)
    logging.info('Data saved to the database')

def _store_in_database(events):
    """
    Stores the processed events in the database:.

    @param events: The list of events to store.
    @type events: list
    """
    connection = get_db_connection()
    if connection is None:
        logging.error("Failed to connect to database.")
        return
    cursor = connection.cursor()

    try:
        for event in events:
            cursor.execute(
                "INSERT INTO events (repo_name, event_time, event_type) VALUES (%s, %s, %s)",
                (event['repo_name'], event['event_time'], event['event_type'])
            )
        connection.commit()
        logging.info(f"Inserted {len(events)} events into the database")
    except mysql.connector.Error as err:
        logging.error(f"Error: {err}")
        connection.rollback()
    finally:
        cursor.close()
        connection.close()

def _calculate_and_store_statistics():
    """
    Calculates the average time between events 
    and stores the statistics in the database.
    """
    connection = get_db_connection()
    if connection is None:
        logging.error("Failed to connect to database.")
        return
    cursor = connection.cursor()

    try:
        cursor.execute("""
        SELECT repo_name, event_type, event_time 
        FROM events 
        WHERE event_time >= NOW() - INTERVAL %s DAY 
        ORDER BY repo_name, event_type, event_time ASC
        """, (ROLLING_WINDOW_DAYS,))

        events = cursor.fetchall()

        if len(events) > MAX_EVENTS:
            events = events[:MAX_EVENTS]

        stats = {}
        for event in events:
            key = (event[0], event[1])  # (repo_name, event_type)
            if key not in stats:
                stats[key] = []
            stats[key].append(event[2])  # event_time

        results = []
        for key, times in stats.items():
            if len(times) > 1:
                avg_time = sum((times[i] - times[i-1]).total_seconds() for i in range(1, len(times))) / (len(times) - 1)
                results.append({
                    'repo_name': key[0],
                    'event_type': key[1],
                    'avg_time_between_events': avg_time # in seconds
                })

        cursor.executemany(
            "INSERT INTO statistics (repo_name, event_type, avg_time_between_events) VALUES (%s, %s, %s)",
            [(res['repo_name'], res['event_type'], res['avg_time_between_events']) for res in results]
        )

        connection.commit()
        logging.info(f"Statistics calculated and stored for {len(results)} event types")
    except mysql.connector.Error as err:
        logging.error(f"Error: {err}")
        connection.rollback()
    finally:
        cursor.close()
        connection.close()

@app.route('/statistics', methods=['GET'])
def get_statistics():
    """
    This Flask route handles GET requests to return statistics.

    @return: The JSON response containing the statistics.
    @rtype: flask.Response
    """
    # Get the 'limit' query parameter, defaulting to None if not provided
    limit = request.args.get('limit', default=None, type=int)

    connection = get_db_connection()
    cursor = connection.cursor(dictionary=True)
    
    if limit is not None:
        # Ensure the limit is between 1 and the provided limit
        limit = max(1, limit)
        cursor.execute("""
            SELECT repo_name, event_type, avg_time_between_events 
            FROM statistics
            ORDER BY repo_name, event_type
            LIMIT %s
        """, (limit,))
    else:
        cursor.execute("""
            SELECT repo_name, event_type, avg_time_between_events 
            FROM statistics
            ORDER BY repo_name, event_type
        """)
    
    data = cursor.fetchall()
    cursor.close()
    connection.close()
    logging.info(f"Returning statistics for {len(data)} records")
    return jsonify(data)

def _load_repositories_config():
    """
    Loads the list of repositories from the repositories.json file.

    @return: The repository configuration.
    @rtype: dict
    """  
    with open('repositories.json', 'r') as f:
        return json.load(f)

def _process_events_periodically():
    config = _load_repositories_config()
    repo_names = config['repositories']
    asyncio.run(_process_and_store_events(repo_names))

def _start_scheduled_tasks():
    scheduler = BackgroundScheduler()
    scheduler.add_job(_process_events_periodically, 'interval', minutes=10)
    scheduler.add_job(_calculate_and_store_statistics, 'interval', minutes=30)
    scheduler.add_job(clean_old_events, 'interval', hours=1, misfire_grace_time=None)
    scheduler.start()
    logging.info('Scheduler started')

def main():
    _start_scheduled_tasks()
    logging.info('Application started')
    app.run(host='0.0.0.0', port=5001)

if __name__ == "__main__":
    main()
    